#### Multivariate Statistical Analysis

# Figure 1 (PLS-DA w/ VIP)

## create model

pls_p <- function (df, md) {
  
  d_pc_in <<- df
  
  g1 <- d_pc_in$location
  
  u_mx <- d_pc_in[,-c(1:md)]
  
  pls_in <- plsda(u_mx, 
                  g1, 
                  ncomp = 10)
  
  pls_in <<- pls_in
  
  set.seed(234)
  
  # cross-validation
  
  pls_cv <- perf(pls_in, folds = 5, progressBar = F,
                 auc = T, nrepeat = 5)
  
  
  # error rate
  
  cv1 <- pls_cv$error.rate$overall %>%
    as.data.frame() %>% 
    mutate(val = 'Overall')
  
  cv1$comp <- row.names(cv1)
  
  cv2 <- as.data.frame(pls_cv$error.rate$BER) %>%
    as.data.frame() %>% 
    mutate(val = 'BER')
  
  cv2$comp <- row.names(cv2)
  
  cv_r1 <- rbind(cv1,cv2)
  
  cv_r1$comp <- sub('.*comp', '', cv_r1$comp) %>% 
    as.numeric()
  
  cv_p1 <- cv_r1 %>% 
    pivot_longer(max.dist:mahalanobis.dist,
                 names_to = 'out',
                 values_to = 'Error Rate')
  
  
  # standard deviation
  
  cv3 <- as.data.frame(pls_cv$error.rate.sd$overall) %>%
    as.data.frame() %>% 
    mutate(val = 'Overall')
  
  colnames(cv3) <- paste(colnames(cv3), 
                         'sd', 
                         sep = '.')
  
  cv3$comp <- row.names(cv3)
  
  
  cv4 <- as.data.frame(pls_cv$error.rate.sd$BER) %>%
    as.data.frame() %>% 
    mutate(val = 'BER')
  
  colnames(cv4) <- paste(colnames(cv4), 
                         'sd', 
                         sep = '.')
  
  cv4$comp <- row.names(cv4)
  
  cv_r2 <- rbind(cv3,cv4)
  
  cv_r2$comp <- sub('.*comp', '', cv_r1$comp) %>% 
    as.numeric()
  
  cv_p3 <- cv_r2 %>% 
    pivot_longer(max.dist.sd:mahalanobis.dist.sd,
                 names_to = 'out',
                 values_to = 'Error Rate')
  
  
  
  # create cv plot (scatter)
  
  cv_p2 <- ggplot(cv_p1, aes(x = comp, 
                             y = `Error Rate`, 
                             color = out)) + 
    geom_line(aes(linetype = val)) +
    geom_point() +
    labs(x = 'Component') +
    thm_cvp +
    scale_x_continuous(breaks = c(1,2,3,
                                  4,5,6,
                                  7,8,9,
                                  10)) +
    geom_errorbar(aes(ymin = `Error Rate` - cv_p3$`Error Rate`,
                      ymax = `Error Rate` - cv_p3$`Error Rate`),
                  width = .2,
                  position = position_dodge(0.05))
  
  
  cv_p4 <- cv_p2 + 
    scale_color_manual(values = col1)
  
  cv_p4 <<- cv_p4
  
  # extract vars
  
  axes <- pls_in$variates[['X']]
  g <- g1
  
  pl_in <-  as.data.frame(cbind(axes, g))
  pl_in$g <- as.factor(pl_in$g)
  pl_in$comp1 <- as.numeric(pl_in$comp1)
  pl_in$comp2 <- as.numeric(pl_in$comp2)
  
  
  # format labels for axes
  ax <- pls_in$prop_expl_var[['X']]
  
  
  
  pl1_lab <- function(val, digits = 2, format = 'f') {
    paste0('X-Variate 1 (', formatC(100*val, format = format, digits = digits),
           '%)')
  }
  
  pl2_lab <- function(val, digits = 2, format = 'f') {
    paste0('X-Variate 2 (', formatC(100*val, format = format, digits = digits),
           '%)')
  }
  
  # Create PLS-DA plot
  
  plda <- ggplot(pl_in, aes(x=comp1, 
                            y=comp2, 
                            fill = g)) +
    
    stat_ellipse(geom = "polygon", 
                 col= "black", 
                 alpha =0.25, 
                 show.legend = F) +
    
    geom_point(shape=21, 
               col="black", 
               size = 3) +
    
    labs(y = pl2_lab(ax[2]), 
         x = pl1_lab(ax[1]),
         fill = "Location") +
    
    thm_pca
  
  pl1 <<- plda + 
    scale_fill_manual(values = col1,
                      labels = c("Proximal",
                                 "Distal",
                                 "Parenchyma"))

  }

pls_p(data.log,
      7)

## Output

ggsave(paste(plot.date,
             "_pls_allsamples.png",
             sep = ""),
       pl1,
       width = 7,
       height = 7,
       dpi = 700)

ggsave(paste(plot.date,
             "_pls_crossvald.png",
             sep = ""),
       cv_p4,
       width = 7,
       height = 7,
       dpi = 700)



## VIP

vip.result <- vip(pls_in)

vip.top <- vip.result %>%
  as.data.frame() %>%
  slice_max(comp1,
            n = 500)




