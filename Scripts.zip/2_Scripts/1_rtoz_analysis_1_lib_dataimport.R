#### Load all libraries, plot themes, and import data files



# Libraries

library(readxl)
library(dplyr)
library(extrafont)
library(ggsci)
library(extrafont)
library(openxlsx)
library(kableExtra)
library(cluster)
library(ggfortify)
library(ggpubr)
library(ggplot2)
library(ggforce)
library(mixOmics)
library(ggrepel)
library(here)
library(fuzzyjoin)
library(rstatix)
library(ppcor)
library(RColorBrewer)
library(gplots)
library(dendextend)
library(circlize)
library(stringr)
library(gridtext)
library(corrplot)
library(EnhancedVolcano)
library(magrittr)
library(tibble)
library(gginnards)
library(edgeR)
library(igraph)
library(ggraph)
library(viridis)
library(topGO)
library(org.Rn.eg.db)
library(reshape2)
library(biomaRt)
library(Rgraphviz)
library(ComplexHeatmap)
library(tidyr)
library(rlang)
library(gtools)


# Plot color schemes

col1 <- c("darkslategrey","mediumpurple3","lightgoldenrod1",
          "aquamarine2","lavender","darkseagreen1",
          "darkolivegreen1","lightgoldenrod4","yellow2",
          "lightsalmon1","orange1","darkorange1",
          "firebrick2","firebrick4")

col2 <- c("darkolivegreen","firebrick2","firebrick4")

col3 <- c("darkslategrey","mediumpurple3","lightgoldenrod1",
          "firebrick2")
                         
col_fun = colorRamp2(c(-6,-5,-4,
                       -3,-2,-1,
                       0,1,2,
                       3,4,5,
                       6), 
                     c('midnightblue','royalblue4','royalblue2',
                       'lightskyblue','lightskyblue2',"azure",
                       "white","navajowhite",'goldenrod1',
                       'darkorange1','orangered1',"firebrick1",
                       'coral4'))

col_fun2 <- scale_fill_gradientn(colors = c("royalblue4","deepskyblue","white",
                                            "gold","darkorange2"),
                                 breaks = c(0,0.25,0.5,
                                            0.75,1))

cpp_col <- scale_color_manual( values = c("0" = "black",
                                          "1" = "black",
                                          "2" = "black",
                                          "3" = "black"),
                               guide = "none")



# Plot themes

## PCA/PLS-DA

thm_pca <- theme(plot.title = element_text(hjust = 0.5), 
                 legend.text = element_text(size = 14),
                 legend.title = element_text(size = 16,
                                             face = 'bold'),
                 legend.justification = c('right', 'top'),
                 legend.key.size = unit(0.4,'cm'),
                 legend.key = element_rect(fill = 'white'),
                 legend.position = c(0.975, 0.975),
                 legend.box.just = 'right',
                 axis.text.x = element_text(face = 'bold',
                                            size = 14),
                 axis.text.y = element_text(face = 'bold',
                                            size = 14),
                 panel.border = element_blank(),
                 panel.background = element_blank(),
                 axis.line.y.left = element_line(colour = 'black'),
                 axis.line.x.bottom = element_line(colour = 'black'),
                 panel.grid.major.y = element_line(colour = 'grey85'),
                 panel.grid.major.x = element_blank(),
                 panel.grid.minor.x = element_blank(),
                 axis.ticks.y = element_blank(),
                 strip.background = element_rect(fill = 'slategray2'),
                 strip.text = element_text(face = 'bold',
                                           size = 12),
                 axis.title.x = element_text(face = 'bold',
                                             size = 14),
                 axis.title.y = element_text(face='bold',
                                             size = 14))

## Data distribution

thm_dst <- theme(plot.title = element_text(hjust = 0.5,
                                           face = 'bold'), 
                 legend.text = element_text(size=14, 
                                            face = 'bold'),
                 legend.title = element_blank(),
                 axis.text.x = element_text(face = 'bold',
                                            size = 14),
                 axis.text.y = element_text(face = 'bold',
                                            size = 14),
                 panel.border = element_blank(),
                 panel.background = element_blank(),
                 axis.line.y.left = element_line(colour = 'black'),
                 axis.line.x.bottom = element_line(colour = 'black'),
                 panel.grid.major.y = element_line(colour = 'grey85'),
                 panel.grid.major.x = element_blank(),
                 panel.grid.minor.x = element_blank(),
                 axis.ticks.y = element_blank(),
                 strip.background = element_rect(fill = 'slategray2'),
                 strip.text = element_text(face = 'bold',
                                           size = 12),
                 axis.title.x = element_text(face = 'bold',
                                             size = 14),
                 axis.title.y = element_text(face='bold',
                                             size = 14),
                 legend.key.size = unit(0.4,'cm'),
                 legend.key = element_rect(fill = 'white'),
                 legend.position = 'right')

## PLS-DA cross validation

thm_cvp <- theme(plot.title = element_text(hjust = 0.5), 
                 legend.text = element_text(size=14, 
                                            face = 'bold'),
                 legend.title = element_blank(),
                 legend.justification = c('right', 'top'),
                 axis.text.x = element_text(face = 'bold',
                                            size = 14),
                 axis.text.y = element_text(face = 'bold',
                                            size = 14),
                 panel.border = element_blank(),
                 panel.background = element_blank(),
                 axis.line.y.left = element_line(colour = 'black'),
                 axis.line.x.bottom = element_line(colour = 'black'),
                 panel.grid.major.y = element_line(colour = 'grey85'),
                 panel.grid.major.x = element_blank(),
                 panel.grid.minor.x = element_blank(),
                 axis.ticks.y = element_blank(),
                 strip.background = element_rect(fill = 'slategray2'),
                 strip.text = element_text(face = 'bold',
                                           size = 12),
                 axis.title.x = element_text(face = 'bold',
                                             size = 14),
                 axis.title.y = element_text(face='bold',
                                             size = 14),
                 legend.key.size = unit(0.4,'cm'),
                 legend.key = element_blank(),
                 legend.position = c(0.975, 0.975),
                 legend.box.just = 'right')

## Box plots

thm_box <- theme(plot.title = element_text(hjust = 0.5,
                                           face = 'bold'), 
                 legend.text = element_text(size=14, 
                                            face = 'bold'),
                 legend.title = element_blank(),
                 legend.justification = c('right', 
                                          'top'),
                 axis.text.x = element_text(face = 'bold',
                                            size = 12,
                                            angle = 45,
                                            hjust = 1,
                                            vjust = 0.9),
                 axis.text.y = element_text(face = 'bold',
                                            size = 14),
                 panel.border = element_blank(),
                 panel.background = element_blank(),
                 axis.line.y.left = element_line(colour = 'black'),
                 axis.line.x.bottom = element_line(colour = 'black'),
                 panel.grid.major.y = element_line(colour = 'grey85'),
                 panel.grid.major.x = element_blank(),
                 panel.grid.minor.x = element_blank(),
                 axis.ticks.y = element_blank(),
                 strip.background = element_rect(fill = 'slategray2'),
                 strip.text = element_text(face = 'bold',
                                           size = 12),
                 axis.title.x = element_text(face = 'bold',
                                             size = 14),
                 axis.title.y = element_text(face='bold',
                                             size = 14),
                 legend.key.size = unit(0.4,
                                        'cm'),
                 legend.key = element_blank(),
                 legend.position = "bottom",
                 legend.box.just = 'right')

## Volcano Plots

thm_vol <- theme(plot.title = element_text(hjust = 0.5,
                                           face = 'bold',
                                           size = 14), 
                 axis.text.x = element_text(face = 'bold',
                                            size = 12,
                                            angle = 0,
                                            hjust = 1),
                 axis.text.y = element_text(face = 'bold',
                                            size = 12),
                 panel.border = element_blank(),
                 panel.background = element_blank(),
                 axis.line.y.left = element_blank(),
                 axis.line.x.bottom = element_line(colour = 'black'),
                 panel.grid.major.y = element_line(colour = 'grey85'),
                 panel.grid.major.x = element_blank(),
                 panel.grid.minor.x = element_blank(),
                 axis.ticks.y = element_blank(),
                 strip.background = element_rect(fill = 'slategray2'),
                 strip.text = element_text(face = 'bold',
                                           size = 12),
                 axis.title.x = element_text(face = 'bold',
                                             size = 14),
                 axis.title.y = element_text(face='bold',
                                             size = 14),
                 legend.title = element_text(face = 'bold'),
                 legend.key.size = unit(1,'cm'))

## Circular packing plots

thm_cpp <- theme(legend.title = element_text(size = 20,
                                             face = "bold"),
                 legend.text = element_text(size = 18),
                 legend.key.size = unit(1,
                                        "cm"),
                 
                 panel.background = element_blank())



# Load data

df <- read_excel("20220301_rtoz_normalized counts.xlsx",
                 sheet = 1,
                 col_names = F)

## transpose and replace colnames and rownames

df1 <- df %>%
  t() %>%
  as.data.frame()

names(df1) <- df1[1,]

df1 <- df1[-1,]

row.names(df1) <- seq.int(nrow(df1))

## separate metadata and variables to convert to factor and numeric, respectively
dfmd <- df1[,1:6]

dfv <- df1[,7:ncol(df1)]

### meta-data
dfmd <- as.data.frame(unclass(dfmd),
                      stringsAsFactors = T)

dfmd$SAMPLEID <- as.character(dfmd$SAMPLEID)

### variables
dfv <- as.data.frame(apply(dfv,
                           2,
                           as.numeric))



# Filter Data

## Remove transcripts with low expression
ncol(dfv)

## Remove transcripts with no counts

dfv.fil1 <- dfv[,-which(colMeans(dfv == 0) > 0.99)]

## Transpose and apply low counts filter

dfv.fil2 <- dfv.fil1 %>%
  t() %>%
  as.data.frame()

dfv.fil3 <- filterByExpr(dfv.fil2,
                         group = dfmd$rep)

data.input <- dfv.fil2[dfv.fil3,]

## Recombine data and check data distribution

data.input <- data.input %>%
  t() %>%
  as.data.frame()

data.input <- cbind(dfmd,
              data.input)




