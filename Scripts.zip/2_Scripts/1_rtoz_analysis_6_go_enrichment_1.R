#### GO Enrichment and Circular Packing Plots

# GO enrichment function

GO.enrich <- function(variables,
                      study.desc,
                      go.filename,
                      ind.filename) {
  
  rownames(plot.input.combined) <- plot.input.combined$ID
  
  d.go1 <- plot.input.combined[,variables]
  
  names(d.go1) <- c("ID",
                    "FC.log2",
                    "adjusted.p")
  
  # Create the topGO object
  
  ## genelist
  
  genelist <- d.go1$adjusted.p
  
  names(genelist) <- d.go1$ID
  
  ## topGO object
  
  d.go2 <- new("topGOdata",
               ontology = "BP",
               allGenes = genelist,
               geneSelectionFun = function(x) x < 0.10, 
               annot = annFUN.org, 
               mapping = "org.Rn.eg.db", 
               ID = "ensembl",
               nodeSize = 5)
  
  # Check sig
  
  go.sig <- sample(usedGO(d.go2),
                   10)
  
  go.terms <- termStat(d.go2,
                       go.sig)
  
  sigGenes(d.go2)
  
  # perform enrichment statistics
  
  ## Update study description
  
  description(d.go2) <- paste(description(d.go2),
                              study.desc)
  
  description(d.go2)
  
  ## KS test (Kolmogorov-Smirnov Test)
  
  KS.enrich <- runTest(d.go2, 
                       algorithm = "weight01", 
                       statistic = "KS")
  
  KS.tab <- GenTable(d.go2, 
                     `P-Value` = KS.enrich,
                     topNodes = length(KS.enrich@score),
                     numChar = 120)
  
  KS.tab2 <- KS.tab %>% 
    dplyr::select(GO.ID, 
                  Term, 
                  Annotated,
                  Significant,
                  `P-Value`)
  
  ## keep pathways with p < 0.05 and at least 3 significant differentially expressed genes
  
  KS.tab.out <- KS.tab2 %>%
    filter(`P-Value` < 0.05 &
             Significant >= 3)
  
  ## Export result table
  
  write.xlsx(KS.tab.out,
             go.filename,
             overwrite = T)
  
  ## Unlist topGO object to obtain genes contained within each pathway
  
  genes.in.term <- genesInTerm(d.go2)
  
  gene.terms <- KS.tab.out$GO.ID
  
  genes.in.term2 <- genes.in.term[c(gene.terms)]
  
  genes.in.term3 <- melt(genes.in.term2)
  
  names(genes.in.term3) <- c("ID", "GO.ID")
  
  gene.sig <- sigGenes(d.go2)
  
  ## add rgd symbols to genes and include only significant genes
  
  genes.output <- merge(genes.in.term3,
                        d.go1,
                        by = "ID")
  
  genes.output.sig <- genes.output %>%
    filter(adjusted.p < 0.05)
  
  names(ensembl.rgd) <- c("ID", "RGD.symbol")
  
  genes.output.sig <- merge(genes.output.sig,
                            ensembl.rgd,
                            by = "ID")
  
  ## Export the gene list
  
  write.xlsx(genes.output.sig,
             ind.filename,
             overwrite = T) 
  
  }




