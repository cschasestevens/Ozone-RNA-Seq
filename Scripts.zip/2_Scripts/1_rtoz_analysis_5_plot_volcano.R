#### Volcano Plot based on univariate statistical analysis

# Plot function

generate_vol <- function (df,
                          group_fc, 
                          group_p, 
                          title, 
                          filename) {
  
  
  v_1 <- EnhancedVolcano(df, 
                         lab = df$Name,
                         title = element_blank(),
                         subtitle = element_blank(), 
                         caption = element_blank(), 
                         x= group_fc, 
                         y= group_p,
                         pCutoff = 0.05, 
                         FCcutoff = 1,
                         cutoffLineType = 'twodash',
                         legendLabels = c('NS','Fold Change',
                                          'p-value','FC+P'), 
                         legendLabSize = 12,
                         labFace = 'bold', 
                         col = col3,
                         colAlpha = 0.7,
                         legendIconSize = 4,
                         pointSize = 3,
                         border = 'full',
                         borderWidth = 1.5,
                         legendPosition = 'right',
                         labSize = 3,
                         drawConnectors = T,
                         typeConnectors = "open",
                         min.segment.length = unit(1,
                                                   "mm")
  ) +
    
    thm_vol +
    labs(color='Key') +
    ggtitle(title)
  
  v1 <- v_1 +
    ggplot2::coord_cartesian(xlim=c(-5,5), 
                             ylim = c(0,10)) +
    ggplot2::scale_x_continuous(breaks=seq(-5,5,1))
  
  v1 <- move_layers(v1,
                    "GeomPolygon",
                    position = "bottom")
  
  ggsave(filename, 
         v1, 
         width = 8,
         height = 6,
         dpi = 500)
  
}




