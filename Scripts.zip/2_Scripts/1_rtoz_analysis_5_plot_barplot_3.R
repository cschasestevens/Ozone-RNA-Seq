#### Create boxplot to visualize TW-ANOVA results

# Visualize the TW ANOVA results

## Prepare input df

bp.in <- data.log %>%
  dplyr::select(c(1:7,
                  "ENSRNOG00000004794",
                  "ENSRNOG00000029064",
                  "ENSRNOG00000051970",
                  "ENSRNOG00000027990",
                  "ENSRNOG00000036866",
                  "ENSRNOG00000019964",
                  "ENSRNOG00000010977",
                  "ENSRNOG00000019445"))

## Add gene names

bp.in.names <- as.data.frame(colnames(bp.in[,8:ncol(bp.in)]))

names(bp.in.names) <- "ID"

bp.in.names <- left_join(bp.in.names,
                      plot.input.combined[,c(1:3)],
                      by = "ID")

colnames(bp.in)[8:15] <- bp.in.names$Name

## Filter input data

bp.in <- bp.in %>%
  filter(sex == "F" &
           age == "4 weeks")

bp.in <- melt(bp.in,
              id.vars = c(3,6),
              measure.vars = 8:15)


## Remove observations with values <= 0 

bp.in <- bp.in[-187,]

bp.in <- bp.in[-185,]



## Construct plot

bp.plot <- ggplot(bp.in,
                  aes(x = location,
                      y = value,
                      fill = exposure)) +
  geom_boxplot(show.legend = F) + 
  stat_summary(fun = median,
               geom = "line",
               aes(group = exposure,
                   color = exposure)) +
  scale_y_continuous(name = 'log2 Counts') +
  ggtitle("Two-way ANOVA Interaction - Female 4wks. exposure:location") +
  
  thm_box +
  labs(x = "Lung Region")

## Add custom color palette and facet wrap

bp.plot2 <- bp.plot +
  scale_fill_manual(values = col1) +
  scale_color_manual(values = col1) +
  facet_wrap(~ variable,
             nrow = 2)

## Export the final plot

ggsave(paste(plot.date,
             "_box_fig4.png",
             sep = ""),
       bp.plot2,
       width = 8,
       height = 6,
       dpi = 500)




