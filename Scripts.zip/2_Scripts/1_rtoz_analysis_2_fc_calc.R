#### Group-wise fold change calculation

# prepare df

data <- left_join(data.log[,c("Group",
                              "SAMPLEID")],
                  data.input,
                  by = "SAMPLEID")

fold_prep <- function(md) {
  
  grp <<- data[,"Group"]
  
  mat <<- data %>% 
    dplyr::select(-c(1:md)) %>% 
    as.matrix()
}

fold_prep(7)

# calculate group fold changes

aggr_FUN  <- mean

combi_FUN <- function(x,y) "/"(x,y) 

fold <- function(x, 
                 f, 
                 aggr_FUN = colMeans, 
                 combi_FUN = '/') {
  
  f <- as.factor(f)
  
  i <- split(1:nrow(x), 
             f)
  
  x <- sapply(i, function(i){ aggr_FUN(x[i,])})
  
  x <- t(x)
  
  j <- combn(levels(f), 2)
  
  ret <- combi_FUN(x[j[1,],], 
                   x[j[2,],])
  
  rownames(ret) <- paste(j[1,], 
                         j[2,], 
                         sep = '-')
  
  ret
  
  }

fc <- as.data.frame(fold(mat, grp))

# log2 transformed fold change

fc_log2 <- as.data.frame(apply(fc, 
                               2, 
                               function(x) log2(x)
                               )
                         )


# export with normal and log2 fold changes

fc.export <- function(n) {
  
  export <- createWorkbook()
  
  addWorksheet(export,
               "Log2 Fold Change")
  
  writeData(export, 
            sheet = "Log2 Fold Change",
            x= fc_log2, 
            rowNames = T)
  
  saveWorkbook(export, 
               n)
  
}




