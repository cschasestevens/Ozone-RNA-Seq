#### Multivariate Statistical Analysis - TW ANOVA comparing effect of sex on location specific gene expression

# Table 2 (Combined OW-ANOVA results with Benjamini-Hochberg correction[FDR])

## One-way ANOVA Function

### Convert Group column to factor

data.log$Group <- as.factor(data.log$Group)

### Function

ow_ano <- function(df, sex1, md, md1) {
  
  # filter by sex
  
  d_in <- df %>% 
    filter(sex == sex1)
  
  # OW-ANOVA
  
  m.name <- d_in[,-c(1:md)] %>%
    names()
  
  d_ow <- lapply(d_in[md1:ncol(d_in)],
                 function(x) TukeyHSD(aov(x ~ d_in$`Group`), 
                                      conf.level = 0.95))
  # extract post-hoc result
  
  d_ow_post <- lapply(d_ow, 
                      function(x) lapply(x, 
                                         '[',
                                         ,
                                         "p adj"))
  
  d_ow_post_1 <- as.data.frame(lapply(d_ow_post,'['))
  
  # add names
  
  names(d_ow_post_1) <- m.name
  
  # FDR correction
  
  d_ow.fdr <- as.data.frame(apply(d_ow_post_1,
                                  1,
                                  function(x) as.data.frame(p.adjust(x, 
                                                                     method= "fdr"))))
  
  names(d_ow.fdr) <- row.names(d_ow_post_1)
  
  # Count no. of sig changes for each comparison
  
  
  d_ow.fdr.sig <<- as.data.frame(colSums(d_ow.fdr < 0.05))
  
  return(d_ow.fdr)

  }




