#### Volcano Plot based on univariate statistical analysis

# Select fold change

plot.input.fc <- fc_log2

row.names(plot.input.fc) <- paste(row.names(plot.input.fc),
                                  ".fc",
                                  sep = "")

plot.input.fc <- t(plot.input.fc) %>%
  as.data.frame()

plot.input.fc$ID <- row.names(plot.input.fc)

# Select p-values (combine M and F)

plot.input.p <- cbind(ow_m,
                      ow_f)

plot.input.p$ID <- row.names(plot.input.p)

# Combine fc and p

left_join(plot.input.p,
          plot.input.fc,
          by = "ID") %>%
  dplyr::select(ID,
                everything())

plot.input.combined <- left_join(plot.input.p,
                                 plot.input.fc,
                                 by = "ID") %>%
  dplyr::select(ID,
                everything())

# Add common gene names to input df

rgd.symbols <- plot.input.combined$ID

ensembl.use <- useEnsembl(biomart = "ensembl",
                          dataset = "rnorvegicus_gene_ensembl")

ensembl.rgd <- getBM(attributes = c("ensembl_gene_id",
                                    "rgd_symbol"),
                     filters = "ensembl_gene_id",
                     values = rgd.symbols,
                     mart = ensembl.use)

names(ensembl.rgd) <- c("ID",
                        "Gene Name")

plot.input.combined <- left_join(plot.input.combined,
                                 ensembl.rgd,
                                 by = "ID") %>%
  
  dplyr::select(ID,
                `Gene Name`,
                everything())

# Remove duplicate matches

plot.input.combined <- plot.input.combined[!duplicated(plot.input.combined$ID),]

# Add name column for use in plots

plot.input.combined$Name <- ifelse(is.na(plot.input.combined$`Gene Name`),
                                   plot.input.combined$ID,
                                   ifelse(plot.input.combined$`Gene Name` == "",
                                          plot.input.combined$ID,
                                          plot.input.combined$`Gene Name`))

plot.input.combined <- plot.input.combined %>%
  dplyr::select(Name,
                ID,
                `Gene Name`,
                everything())


# Export plot input df

write.xlsx(plot.input.combined,
           paste(plot.date,
                 "_plot_input.xlsx",
                 sep = ""),
           rowNames = F,
           overwrite = T)




