#### Heatmap based on univariate statistical analysis

# Heatmap Input Data Function

heat.data.fun <- function(comp1,
                          abb1) {
  
  # Select columns for male and female heatmap input
  
  heat.input <- plot.input.combined %>%
    dplyr::select(1,
                  all_of(comp1))
  
  # Filter genes to select only those significant in at least one group
  
  heat.input <- heat.input[which(apply(heat.input[,2:5],
                                       1, 
                                       function (x) any(x < 0.05))),]
  
  # Filter to include overall top 50 transcripts based on fold change (top 50 in each comparison)
  
  heat.filter <- heat.input[,c(1,
                               6:9)]
  
  names(heat.filter) <- abb1
  
  heat.filter <- heat.filter %>%
    melt(id.vars = 1)
  
  heat.filter$value <- abs(heat.filter$value)
  
  heat.filter <- rbind(slice_max(filter(heat.filter,
                                               variable == abb1[2]),
                                        value,
                                        n = 50),
                              slice_max(filter(heat.filter,
                                               variable == abb1[3]),
                                        value,
                                        n = 50),
                              slice_max(filter(heat.filter,
                                               variable == abb1[4]),
                                        value,
                                        n = 50),
                              slice_max(filter(heat.filter,
                                               variable == abb1[5]),
                                        value,
                                        n = 50))
  
  heat.filter <- heat.filter[!duplicated(heat.filter$name),]
  
  # heat.input <- heat.input %>%
  #   filter(Name %in% heat.filter$name)
  
  # Format data set for heatmap input
  
  row.names(heat.input) <- heat.input$Name
  
  ## Fold Change
  
  heat.input.fc <- t(as.matrix(heat.input[,c(6:9)]))
  
  ## P-values
  
  heat.input.pv <- t(as.matrix(heat.input[,c(2:5)]))
  
  return(heat.input.fc)
  
  }

# Female input

heat.female.input <- heat.data.fun(heat.female,
                                   heat.female.abb)

# Male input

heat.male.input <- heat.data.fun(heat.male,
                                 heat.male.abb)



# Generate plots

## common gene names

# row.ha <- rowAnnotation(Age = as.matrix(age.anno),
#                         col = list(Age = c("4wks." = "lightcyan3",
#                                            "8wks." = "darkslategrey")),
#                         annotation_name_gp = gpar(fontsize = 8))
# row.lab <- c("Female Filtered Air",
#              "Female Ozone",
#              "Female Filtered Air",
#              "Female Ozone",
#              "Male Filtered Air",
#              "Male Ozone",
#              "Male Filtered Air",
#              "Male Ozone")

## plot function

h1.fun <- function (df) {
  
  h1 <-    Heatmap(df,
                   ## Rows
                   row_dend_side = 'left', show_row_names = F,
                   row_names_side = 'left', row_title_side = 'right',
                   row_names_gp= gpar(fontsize= 10, 
                                      font= 2), show_row_dend = T,
                   ## Columns
                   column_title_side = 'bottom', show_column_names = F,
                   column_names_rot = 45, column_names_gp = gpar(fontsize = 7.5, 
                                                                 font= 2),
                   column_dend_height = unit(4,
                                             'cm'),
                   ## General settings
                   border = F, 
                   clustering_distance_rows = 'euclidean', 
                   cluster_rows = T, 
                   cluster_columns = T,
                   ## Legend parameters
                   heatmap_legend_param = list(title= '',
                                               legend_height= unit(8,
                                                                   'cm'),
                                               at= c(-6,-5,-4,
                                                     -3,-2,-1,
                                                     0,
                                                     1,2,3,
                                                     4,5,6),
                                               labels_gp= gpar(fontsize= 12),
                                               title_gp= gpar(fontsize= 10,
                                                              font= 2)),
                   ## Height and width
                   # rect_gp = gpar(col = "white",
                   #                lwd = 2),
                   heatmap_height= unit(10,
                                        'cm'), 
                   heatmap_width = unit(35,
                                        'cm'),
                   col = col_fun)
  
  # Draw heatmap
  
  h1_p <<- draw(h1,
                heatmap_legend_side='right')
  }




