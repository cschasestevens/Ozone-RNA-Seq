#### Data transformation and quality check



# Data distribution (without log transformation)

## density plot (data frame, mdata + 1, plot.title)

dst <- function(df, md1, pn) {
  dsty <- as.data.frame(colMeans(df[md1:ncol(df)]))
  
  names(dsty) <- c("Counts per Million")
  
  p <- ggplot(dsty, 
              aes(x=`Counts per Million`)) +
    geom_density(color = 'darkslategrey', 
                 fill = 'mediumpurple3')+
    labs(title = 'CPM Distribution' , 
         y= "Density")+
    theme_bw()+
    thm_dst
  
  ggsave(pn,
         p,
         width = 8,
         height = 6,
         dpi = 500)
  
}



# log2-transformed data distribution

## log transform function (data frame, mdata no.)

lg2_trf <- function(df, md){
  
  #remove metadata
  d_log2 <- df %>% 
    dplyr::select(-c(1:md))
  
  mdata <- df %>% 
    dplyr::select(1:md)
  
  #perform log transformation
  d_log2 <- as.data.frame(lapply(d_log2[,1:ncol(d_log2)], 
                                 function(x) log2(x)))
  
  #recombine the metadata
  d_log2 <- cbind(mdata, 
                  d_log2)
  
  #clean up column names
  names(d_log2) <- names(df)
  
  #export the combined normalized, transformed dataset
  return(d_log2)
  
}

data.log <- lg2_trf(data.input, 
                    6)



## Rename location, age, and exposure variables

data.log$exposure <- ifelse(data.log$exposure == "Oz",
                            "Ozone",
                            "Filtered Air")

data.log$location <- ifelse(data.log$location == "prox",
                            "Proximal",
                            ifelse(data.log$location == "distal",
                                   "Distal",
                                   "Parenchyma"))

data.log$age <- ifelse(data.log$age == "4Wk",
                       "4 weeks",
                       "12 weeks")

## Reorder factor variables in log-transformed data

data.log$location <- factor(data.log$location,
                            levels = c('Proximal',
                                       'Distal',
                                       'Parenchyma'))

data.log$sex <- factor(data.log$sex,
                            levels = c('M',
                                       'F'))

data.log$age <- factor(data.log$age,
                       levels = c("4 weeks",
                                  "12 weeks"))

data.log$exposure <- factor(data.log$exposure,
                            levels = c("Filtered Air",
                                       "Ozone"))

## Add group column

data.log$Group <- paste(data.log$sex,
                        data.log$age,
                        data.log$location,
                        data.log$exposure)

data.log <- data.log %>%
  dplyr::select(Group, 
                everything())


