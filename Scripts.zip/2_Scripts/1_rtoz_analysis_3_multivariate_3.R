#### Multivariate Statistical Analysis - TW ANOVA comparing effect of exposure on location specific gene expression

# Table S1 (TW ANOVA Interaction)

# TW ANOVA function

tw_ano <- function(df,
                   md,
                   md1,
                   v1,
                   v2,
                   int1) {
  
  # Apply TW ANOVA
  
  d_tw <- lapply(df[md1:ncol(df)],
                 function(x) summary(aov(x ~ unlist(df[v1]) * 
                                           unlist(df[v2]))))
  
  d_tw2 <- lapply(d_tw, 
                  function(x) lapply(x, 
                                     '[',
                                     ,
                                     "Pr(>F)"))
  
  d_tw3 <- as.data.frame(lapply(d_tw2,
                                '['))
  
  d_tw4 <- d_tw3[1:3,]
  
  names(d_tw4) <- names(df[,md1:ncol(df)])
  
  row.names(d_tw4) <- c(v1,
                        v2,
                        int1)
  
  # Raw p-values
  
  d_tw4 <<- d_tw4
  
  # FDR correction
  
  d_tw4.fdr <- as.data.frame(apply(d_tw4,
                                   1,
                                   function(x) as.data.frame(p.adjust(x, 
                                                                      method= "fdr"))))
  
  names(d_tw4.fdr) <- c(v1,
                        v2,
                        int1)
  
  d_tw4.fdr <<- d_tw4.fdr
  
  }


## Function for creating result table with Excel

tw.export1 <- function(n) {
  
  export <- createWorkbook()
  
  addWorksheet(export,
               "raw.p")
  
  addWorksheet(export,
               "fdr.p")
  
  addWorksheet(export,
               "raw.p.sig")
  
  addWorksheet(export,
               "fdr.p.sig")
  
  writeData(export, 
            sheet = "raw.p",
            x= d_tw4, 
            rowNames = T)
  
  writeData(export, 
            sheet = "fdr.p",
            x= d_tw4.fdr, 
            rowNames = T)
  
  writeData(export, 
            sheet = "raw.p.sig",
            x= d_tw4.sig, 
            rowNames = T)
  
  writeData(export, 
            sheet = "fdr.p.sig",
            x= d_tw4.fdr.sig, 
            rowNames = T)
  
  saveWorkbook(export, 
               n)
  
}




