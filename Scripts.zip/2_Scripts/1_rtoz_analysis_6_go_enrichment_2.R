#### GO Enrichment and Circular Packing Plots

# Circular packing map for significant GO terms

## Data frames must be formatted outside of R to create hierarchy
## Hierarchies are based on the first three terms in each ancestry tree

circular.packing <- function(go.df,
                             ind.df,
                             edge.output.name,
                             plot.output.name) {
  
  # Read the formatted Excel file that contains hierarchy levels
  
  cp.in <- read.xlsx(go.df)
  
  ## Select first 25 GO terms
  
  cp.in <- cp.in[1:25,]
  
  ## Change variable format and calculate log10 P-value
  
  cp.in$`P-Value` <- as.numeric(cp.in$`P-Value`)
  
  cp.in$`-log2p` <- -log2(cp.in$`P-Value`)
  
  # Calculate the ratio of significant genes with increased expression and include in df
  
  ## This ratio is calculated for each individual GO term and averaged for each parent level in the hierarchy to generate the CP plot
  
  ## KEY (1 = All increased in expression,
  ##      0.5 - 0.99 = Mostly increases,
  ##      0.01 - 0.49 = Mostly decreases,
  ##      0 = All decreased)
  
  ## Read df containing individual gene fold changes
  
  ar <- read.xlsx(ind.df)
  
  ## Remove Ensembl IDs and adjusted p-values
  
  ar <- ar[-c(1,4)]
  
  ## Assign directions for fold changes and combine into single df
  
  ar$direction <- ifelse(ar$FC.log2 > 0, 
                         "Increased",
                         "Decreased")
  
  ar.count <- ar %>%
    group_by(GO.ID) %>%
    count(direction)
  
  ar.count.inc <- ar.count %>%
    filter(direction == "Increased")
  
  ar.count.dec <- ar.count %>%
    filter(direction == "Decreased")
  
  ar.count.full <- full_join(ar.count.inc,
                             ar.count.dec,
                             by = "GO.ID")
  
  ar.count.full$n.x[is.na(ar.count.full$n.x)] <- 0
  
  ar.count.full$direction.x[is.na(ar.count.full$direction.x)] <- "Increased"
  
  ar.count.full$n.y[is.na(ar.count.full$n.y)] <- 0
  
  ar.count.full$direction.y[is.na(ar.count.full$direction.y)] <- "Decreased"
  
  ar.count.full$tot.count <- ar.count.full[-1] %>%
    dplyr::select(n.x,
                  n.y) %>%
    rowSums()
  
  ar.count.full$increased.ratio <- ar.count.full$n.x /
    ar.count.full$tot.count
  
  ar.merge <- ar.count.full %>%
    dplyr::select(GO.ID,
                  increased.ratio)
  
  cp.in <- left_join(cp.in,
                     ar.merge,
                     by = "GO.ID")
  
  # Select variables for edge and vertices lists from cp.in
  
  edges <- cp.in %>%
    dplyr::select(Term,
                  Level1,
                  Level2,
                  Level3,
                  `-log2p`,
                  increased.ratio)
  
  ## reorder variables
  
  edges <- edges %>%
    dplyr::select(2,
                  3,
                  4,
                  1,
                  5,
                  6)
  
  
  ## Calculate level ratio averages
  
  l1.avg <- aggregate(edges$increased.ratio,
                      list(edges$Level1),
                      FUN = mean)
  
  names(l1.avg) <- c("Level1",
                     "l1.avg")
  
  edges <- left_join(edges,
                     l1.avg,
                     by = "Level1")
  
  l2.avg <- aggregate(edges$increased.ratio,
                      list(edges$Level2),
                      FUN = mean)
  
  names(l2.avg) <- c("Level2",
                     "l2.avg")
  
  edges <- left_join(edges,
                     l2.avg,
                     by = "Level2")
  
  l3.avg <- aggregate(edges$increased.ratio,
                      list(edges$Level3),
                      FUN = mean)
  
  names(l3.avg) <- c("Level3",
                     "l3.avg")
  
  edges <- left_join(edges,
                     l3.avg,
                     by = "Level3")
  
  ## Export the edge list
  
  write.xlsx(edges,
             edge.output.name,
             overwrite = T)
  
  # Assign edges for each plot
  
  ## Level 1
  
  edges.l1 <- as.data.frame(edges$Level1)
  
  names(edges.l1) <- "edge"
  
  edges.l1$size <- 0
  
  edges.l1$depth <- edges$l1.avg
  
  ## Level 2
  
  edges.l2 <- as.data.frame(paste(edges$Level1,
                                  edges$Level2,
                                  sep = "."))
  
  names(edges.l2) <- "edge"
  
  edges.l2$size <- 0.4
  
  edges.l2$depth <- edges$l2.avg
  
  
  ## Level 3
  
  edges.l3 <- as.data.frame(paste(edges.l2$edge,
                                  edges$Level3,
                                  sep = "."))
  
  names(edges.l3) <- "edge"
  
  edges.l3$size <- 0.6
  
  edges.l3$depth <- edges$l3.avg
  
  ## Level 4 (individual GO terms)
  
  edges.to <- as.data.frame(paste(edges.l3$edge,
                                  edges$Term,
                                  sep = "."))
  
  names(edges.to) <- "edge"
  
  edges.to$size <- edges$`-log2p`
  
  edges.to$depth <- edges$increased.ratio
  
  # Combine into a single data frame
  
  edge.names <- c("from",
                  "to",
                  "size",
                  "depth")
  
  edges.l1.l2 <- cbind(edges.l1$edge,
                       edges.l2)
  
  edges.l2.l3 <- cbind(edges.l2$edge,
                       edges.l3)
  
  edges.l3.to <- cbind(edges.l3$edge,
                       edges.to)
  
  
  names(edges.l1.l2) <- edge.names
  
  names(edges.l2.l3) <- edge.names
  
  names(edges.l3.to) <- edge.names
  
  
  edges.comb <- rbind(edges.l1.l2,
                      edges.l2.l3,
                      edges.l3.to)
  
  # Final edge and vertex list
  
  edges.input <- rbind(edges.l1.l2[1:2],
                       edges.l2.l3[1:2],
                       edges.l3.to[1:2])
  
  vertices.input <- as.data.frame(rbind(edges.l1,
                                        edges.l2,
                                        edges.l3,
                                        edges.to))
  
  
  # Create label column for plot output and make graph input df
  
  vertices.input$shortname <- sub('.*\\.',
                                  '',
                                  vertices.input$edge)
  
  vertices.input <- vertices.input[!duplicated(vertices.input$edge),]
  
  
  
  mygraph <- graph_from_data_frame(edges.input,
                                   vertices = vertices.input)
  
  
  # Plot output
  
  cp.out <- ggraph(mygraph, 
                   layout = 'circlepack',
                   weight = size) + 
    
    geom_node_circle(aes(fill = vertices.input$depth,
                         color = as.factor(depth))) +
    
    # geom_node_label(aes(label = shortname,
    #                     filter = leaf),
    #                 label.size = 0.15,
    #                 repel = T,
    #                 label.padding = 0.15,
    #                 size = 6) +
    
    col_fun2 +
    
    labs(fill = "Increased Ratio") +
    
    thm_cpp +
    
    cpp_col
  
  # Save the plot
  
  ggsave(plot.output.name,
         cp.out,
         width = 14,
         height = 12,
         dpi = 700)
  
  }




